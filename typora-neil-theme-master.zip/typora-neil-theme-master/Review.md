---
Author: Neil
Since: 2023年02月01日
---

[TOC]

---

# Header 1 1==1

## Header 2

### Header 3

#### Header 4

##### Header 5

###### Header 6

## font

<u>Underline</u> ~~Line-Through~~ **Blod** *italics* `code` [Linked To Baidu](https://www.baidu.com) ==高亮== $f(n)=x^2$ H~2~O f(n)=x^2^ 1==1 1>=1

## Blockquote

> dont waste life in doubts and fears. ——emerson
>
> A great man is always willing to be little.—R. W. Emerson
>
> 1==1 0!=1 1>=1 1>0 0<1 1<=1 

## Code

```java
public class Main{
    public static void main(String[] args){
        int x = 1;
        int y = 0;
        if(x==y){
            System.out.println("equals");
        }else if(x>y){
            System.out.println("x gt y!");
        }else if(x<y){
            System.out.println("x lt y!");
        }
        if(x>=0){
            System.out.println("x gte zero!");
        }else(x<=0){
            System.out.println("x lte zero!");
        }else{
            System.out.println("never run here!");
        }
    }
}
```

## Table

### Markdown Table

| id[^0] | name[^1] | code[^2] |
| ------ | -------- | -------- |
| 1      | Jack     | C001     |
| 2      | Neil     | C002     |
| 3      | Tom      | C003     |

------

### HTML Table


<table> <thead> <tr cid="n21" mdtype="table_row"> <th><span contenteditable="true" cid="n22" mdtype="table_cell"><span md-inline="plain">id</span><sup md-inline="footnote" data-ref="0"></sup></span></th> <th><span contenteditable="true" cid="n23" mdtype="table_cell"><span md-inline="plain">name</span><sup md-inline="footnote" data-ref="1"></sup></span></th> <th><span contenteditable="true" cid="n24" mdtype="table_cell"><span md-inline="plain">code</span><sup md-inline="footnote" data-ref="2"><span></span></sup></span></th> </tr> </thead> <tbody> <tr cid="n25" mdtype="table_row"> <td><span contenteditable="true" cid="n26" mdtype="table_cell"><span md-inline="plain">1</span></span></td> <td><span contenteditable="true" cid="n27" mdtype="table_cell"><span md-inline="plain">Jack</span></span></td> <td><span contenteditable="true" cid="n28" mdtype="table_cell"><span md-inline="plain">C001</span></span></td> </tr> <tr cid="n29" mdtype="table_row"> <td><span contenteditable="true" cid="n30" mdtype="table_cell"><span md-inline="plain">2</span></span></td> <td><span contenteditable="true" cid="n31" mdtype="table_cell"><span md-inline="plain">Neil</span></span></td> <td><span contenteditable="true" cid="n32" mdtype="table_cell"><span md-inline="plain">C002</span></span></td> </tr> <tr cid="n33" mdtype="table_row"> <td><span contenteditable="true" cid="n34" mdtype="table_cell"><span md-inline="plain">3</span></span></td> <td><span contenteditable="true" cid="n35" mdtype="table_cell"><span md-inline="plain">Tom</span></span></td> <td><span contenteditable="true" cid="n36" mdtype="table_cell"><span md-inline="plain">C003</span></span></td> </tr> </tbody></table>

## Math

$$
f(n)=x^2
$$

## Images

### Type 1

![Img](./img.jpg)

### Type 2

![da][1]

[1]: ./img.jpg	"dadada"


## Order List

1. One-1
   1. Second-1
      - [x] Todo list one 
      - [ ] Todo list two

2. One-2
3. One-3

- One-1
  - Two
    - Three



## Footnotes

[^0]: id
[^1]: 姓名
[^2]: 编码